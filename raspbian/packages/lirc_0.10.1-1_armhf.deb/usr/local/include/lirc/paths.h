#ifndef PATHS_H
#define PATHS_H
#define DATADIR          "/usr/share"
#define SYSCONFDIR       "/etc"
#define VARRUNDIR        "/var/run"
#define LOCALSTATEDIR    "/var"
#define LIBDIR           "/usr/local/lib"
#endif
