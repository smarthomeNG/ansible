/* 
     EIBD client library
     Copyright (C) 2005-2011 Martin Koegler <mkoegler@auto.tuwien.ac.at>
   
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.
   
     In addition to the permissions in the GNU General Public License, 
     you may link the compiled version of this file into combinations
     with other programs, and distribute those combinations without any 
     restriction coming from the use of this file. (The General Public 
     License restrictions do apply in other respects; for example, they 
     cover modification of the file, and distribution when not linked into 
     a combine executable.)
   
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
   
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/ 

package eibd

import (
  "fmt"
  "net"
  "strconv"
  "strings"
  "time"
)


type DevAddr EIBAddr

func DevAddrFromString(addr string) (DevAddr,error) {
  var a,b,c uint8
  if n,err := fmt.Sscanf(addr, "%d.%d.%d", &a, &b, &c); n<3 {
    return 0,err
  }
  return (DevAddr(a&0x0f)<<12) | (DevAddr(b&0x0f)<<8) | DevAddr(c&0xff),nil
}

func (addr DevAddr) String() string {
  return fmt.Sprintf("%d.%d.%d", uint8(addr>>12)&0x0F,
                                 uint8(addr>>8)&0x0F,
                                 uint8(addr)&0xFF)
}



type GroupAddr EIBAddr

func GroupAddrFromString(addr string) (GroupAddr,error) {
  var a,b,c uint
  var af,bf,cf GroupAddr
  n,_ := fmt.Sscanf(addr, "%d/%d/%d", &a, &b, &c)

  if n == 3 && a <= 0x1F && b <= 0x07 && c <= 0xFF {
    af = GroupAddr(a)
    bf = GroupAddr(b)
    cf = GroupAddr(c)
    return (af<<11) | (bf<<8) | cf, nil
  }
  if n == 2 && a <= 0x1F && b <= 0x7FF {
    af = GroupAddr(a)
    bf = GroupAddr((b>>8)&0x07)
    cf = GroupAddr(b&0xFF)
    return (af<<11) | (bf<<8) | cf, nil
  }

  n,_ = fmt.Sscanf (addr, "%x", &a)
  if n == 1 && a <= 0xFFFF {
    af = GroupAddr((a>>11)&0x1F)
    bf = GroupAddr((a>>8)&0x07)
    cf = GroupAddr(a&0xFF)
    return (af<<11) | (bf<<8) | cf, nil
  }

  return 0,fmt.Errorf("Invalid Group Address")
}

func (addr GroupAddr) String() string {
  return fmt.Sprintf("%d/%d/%d", uint8(addr>>11)&0x1F,
                                 uint8(addr>>8)&0x07,
                                 uint8(addr)&0xFF)
}


type CompleteFunc func() (int,error)

type EIBAddr uint16

type EIBConnection struct {
    head       []byte
    data       []byte
    readlen    int
    datalen    int
    sendlen    int
    con        net.Conn
    buffer     []byte
    __complete CompleteFunc
    ptr1       *uint16
    ptr2       *uint8
    ptr3       *uint8
    ptr4       *uint16
    ptr5       *uint16
    ptr6       *uint16
    ptr7       *uint32
}

func NewEIBConnection() (*EIBConnection) {
    return &EIBConnection{nil,nil,0,0,0,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
}

func (this *EIBConnection) EIBSocketLocal(path string) (error) {

    if this.con != nil {
      return fmt.Errorf("Connection already open")
    }
    var err error
    this.con,err = net.Dial("unix", path)
    if err != nil {
      return err
    }
    this.data = nil
    this.readlen = 0
    return nil
}

func (this *EIBConnection) EIBSocketRemote(host string, port uint16) (error) {

    if this.con != nil {
      return fmt.Errorf("Connection already open")
    }
    var hostport string
    fmt.Sprintf(hostport,"%s:%d",host,port)
    var err error
    this.con,err = net.Dial("tcp", hostport)
    if err != nil {
      return err
    }
    this.data = nil
    this.readlen = 0
    return nil
}

func (this *EIBConnection) EIBSocketURL(url string) (error) {

    if url[0:6] == "local:" {
      return this.EIBSocketLocal(url[6:])
    }
    if url[0:3] == "ip:" {
         parts := strings.Split(url,":")
         if len(parts) == 2 {
             parts = append(parts,"6720")
         }
         port,err := strconv.Atoi(parts[2])
         if err != nil || port<0 || port>65535 {
            return fmt.Errorf("Port invalid")
         }
         return this.EIBSocketRemote(parts[1], uint16(port))
    }
    return fmt.Errorf("Protocol invalid")
}

func (this *EIBConnection) EIBComplete() (int,error) {
    if this.__complete == nil {
        return 0,fmt.Errorf("Already completed")
    }
    return this.__complete()
}

func (this *EIBConnection) EIBClose() (error) {
    if this.con == nil {
      return fmt.Errorf("Close failed, not connected")
    }
    this.con.Close()
    this.con = nil
    return nil
}

func (this *EIBConnection) EIBClose_sync() (error) {
    this.EIBReset()
    return this.EIBClose()
}

func (this *EIBConnection) __EIB_SendRequest(data []byte) (error) {
    if this.con == nil {
      return fmt.Errorf("Not connected")
    }
    if len(data) < 2 || len(data) > 0xffff {
      return fmt.Errorf("Invalid data")
    }
    headdata := []byte{ byte((len(data)>>8)&0xff), byte((len(data))&0xff) }
    data = append(headdata,data...)
    _,err := this.con.Write(data) // TODO evtl evaluate n
    return err
}

func (this *EIBConnection) EIB_Poll_FD() (int, error) {
    if this.con == nil {
      return 0,fmt.Errorf("Not connected")
    }
    return 0,fmt.Errorf("Not yet implemented") // TODO
}

func (this *EIBConnection) EIB_Poll_Complete() (bool,error) {
    if this.__EIB_CheckRequest(false) != nil {
      return false,fmt.Errorf("Request failed")
    }
    if this.readlen < 2 || (this.readlen >= 2 && this.readlen < this.datalen + 2) {
      return false,nil
    }
    return true,nil
}

func (this *EIBConnection) __EIB_GetRequest() (error) {
    for {
        if this.__EIB_CheckRequest(true) != nil {
            return fmt.Errorf("Request failed")
        }
        if this.readlen >= 2 && this.readlen >= this.datalen + 2 {
            this.readlen = 0
            return nil
        }
    }
}

func (this *EIBConnection) __EIB_CheckRequest(block bool) (error) {

    if this.con == nil {
      return fmt.Errorf("Not connected")
    }

    if this.readlen == 0 {
      this.head = []byte{}
      this.data = []byte{}
    }
    if this.readlen < 2 {
      if block == true {
        this.con.SetDeadline(time.Time{})
      } else {
        this.con.SetDeadline(time.Now().Add(1*time.Millisecond))
      }
      buf := make([]byte, 2-this.readlen)
      n,err := this.con.Read (buf)
      this.con.SetDeadline(time.Time{}) // reset the absolute deadline
      if err != nil {
        return err
      }
      this.head = append(this.head,buf...)
      this.readlen += n
    }
    if this.readlen < 2 {
      return nil
    }
    this.datalen = int( (this.head[0] << 8) | this.head[1] )
    if this.readlen < this.datalen + 2 {
      if block == true {
        this.con.SetDeadline(time.Time{})
      } else {
        this.con.SetDeadline(time.Now().Add(1*time.Millisecond))
      }
      buf := make([]byte, this.datalen + 2-this.readlen)
      n,err := this.con.Read (buf)
      this.con.SetDeadline(time.Time{}) // reset the absolute deadline
      if err != nil {
        return err
      }
      this.data = append(this.data,buf...)
      this.readlen += n
    }
    return nil
}


func (this *EIBConnection) __EIBGetAPDU_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 37 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIBGetAPDU_async(buf []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    this.__complete = this.__EIBGetAPDU_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetAPDU(buf []byte) (int,error) {
    _,err := this.EIBGetAPDU_async (buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBGetAPDU_Src_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 37 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr5 != nil {
      *(this.ptr5) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return copy(this.buffer, this.data[4:]),nil
}

func (this *EIBConnection) EIBGetAPDU_Src_async(buf []byte, src *EIBAddr) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    this.ptr5 = (*uint16)(src)
    this.__complete = this.__EIBGetAPDU_Src_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetAPDU_Src(buf []byte, src *EIBAddr) (int,error) {
    _,err := this.EIBGetAPDU_Src_async (buf, src)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBGetBusmonitorPacket_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 20 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIBGetBusmonitorPacket_async(buf []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    this.__complete = this.__EIBGetBusmonitorPacket_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetBusmonitorPacket(buf []byte) (int,error) {
    _,err := this.EIBGetBusmonitorPacket_async (buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBGetBusmonitorPacketTS_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 21 || len(this.data) < 7 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr2 != nil {
      *(this.ptr2) = this.data[2]
    }
    if this.ptr7 != nil {
      *(this.ptr7) = uint32(((this.data[3])<<24)|((this.data[3+1])<<16)|((this.data[3+2])<<8)|(this.data[3+3]))
    }
    return copy(this.buffer, this.data[7:]),nil
}

func (this *EIBConnection) EIBGetBusmonitorPacketTS_async(status *uint8, timestamp *uint32, buf []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.ptr2 = (*uint8)(status)
    this.ptr7 = (*uint32)(timestamp)
    this.buffer = buf
    this.__complete = this.__EIBGetBusmonitorPacketTS_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetBusmonitorPacketTS(status *uint8, timestamp *uint32, buf []byte) (int,error) {
    _,err := this.EIBGetBusmonitorPacketTS_async (status, timestamp, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBGetGroup_Src_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 39 || len(this.data) < 6 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr5 != nil {
      *(this.ptr5) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    if this.ptr6 != nil {
      *(this.ptr6) = uint16(((this.data[4])<<8)|(this.data[4+1]))
    }
    return copy(this.buffer, this.data[6:]),nil
}

func (this *EIBConnection) EIBGetGroup_Src_async(buf []byte, src *EIBAddr, dest *EIBAddr) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    this.ptr5 = (*uint16)(src)
    this.ptr6 = (*uint16)(dest)
    this.__complete = this.__EIBGetGroup_Src_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetGroup_Src(buf []byte, src *EIBAddr, dest *EIBAddr) (int,error) {
    _,err := this.EIBGetGroup_Src_async (buf, src, dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBGetTPDU_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 37 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr5 != nil {
      *(this.ptr5) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return copy(this.buffer, this.data[4:]),nil
}

func (this *EIBConnection) EIBGetTPDU_async(buf []byte, src *EIBAddr) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    this.ptr5 = (*uint16)(src)
    this.__complete = this.__EIBGetTPDU_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBGetTPDU(buf []byte, src *EIBAddr) (int,error) {
    _,err := this.EIBGetTPDU_async (buf, src)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Clear_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 114 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Clear_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 114
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Clear_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Clear() (int,error) {
    _,err := this.EIB_Cache_Clear_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Disable_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 113 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Disable_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 113
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Disable_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Disable() (int,error) {
    _,err := this.EIB_Cache_Disable_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Enable_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 112 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Enable_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 112
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Enable_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Enable() (int,error) {
    _,err := this.EIB_Cache_Enable_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Read_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 117 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if uint16(((this.data[4])<<8)|(this.data[4+1])) == 0 {
      return 0,fmt.Errorf("ENODEV")
    }
    if len(this.data) <= 6 {
      return 0,fmt.Errorf("ENOENT")
    }
    if this.ptr5 != nil {
      *(this.ptr5) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return copy(this.buffer, this.data[6:]),nil
}

func (this *EIBConnection) EIB_Cache_Read_async(dst EIBAddr, src *EIBAddr, buf []byte) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    this.buffer = buf
    this.ptr5 = (*uint16)(src)
    ibuf[2] = byte((dst>>8)&0xff)
    ibuf[3] = byte((dst)&0xff)
    ibuf[0] = 0
    ibuf[1] = 117
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Read_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Read(dst EIBAddr, src *EIBAddr, buf []byte) (int,error) {
    _,err := this.EIB_Cache_Read_async (dst, src, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Read_Sync_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 116 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if uint16(((this.data[4])<<8)|(this.data[4+1])) == 0 {
      return 0,fmt.Errorf("ENODEV")
    }
    if len(this.data) <= 6 {
      return 0,fmt.Errorf("ENOENT")
    }
    if this.ptr5 != nil {
      *(this.ptr5) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return copy(this.buffer, this.data[6:]),nil
}

func (this *EIBConnection) EIB_Cache_Read_Sync_async(dst EIBAddr, src *EIBAddr, buf []byte, age uint16) (int,error) {
    ibuf := make([]byte,6);
    _ = ibuf
    this.buffer = buf
    this.ptr5 = (*uint16)(src)
    ibuf[2] = byte((dst>>8)&0xff)
    ibuf[3] = byte((dst)&0xff)
    ibuf[4] = byte((age>>8)&0xff)
    ibuf[5] = byte((age)&0xff)
    ibuf[0] = 0
    ibuf[1] = 116
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Read_Sync_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Read_Sync(dst EIBAddr, src *EIBAddr, buf []byte, age uint16) (int,error) {
    _,err := this.EIB_Cache_Read_Sync_async (dst, src, buf, age)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_Remove_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 115 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Remove_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 115
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_Remove_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_Remove(dest EIBAddr) (int,error) {
    _,err := this.EIB_Cache_Remove_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_LastUpdates_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 118 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr4 != nil {
      *(this.ptr4) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return copy(this.buffer, this.data[4:]),nil
}

func (this *EIBConnection) EIB_Cache_LastUpdates_async(start uint16, timeout uint8, buf []byte, ende *uint16) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    this.buffer = buf
    this.ptr4 = (*uint16)(ende)
    ibuf[2] = byte((start>>8)&0xff)
    ibuf[3] = byte((start)&0xff)
    ibuf[4] = byte((timeout)&0xff)
    ibuf[0] = 0
    ibuf[1] = 118
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_LastUpdates_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_LastUpdates(start uint16, timeout uint8, buf []byte, ende *uint16) (int,error) {
    _,err := this.EIB_Cache_LastUpdates_async (start, timeout, buf, ende)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_Cache_LastUpdates2_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 119 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr7 != nil {
      *(this.ptr7) = uint32(((this.data[2])<<24)|((this.data[2+1])<<16)|((this.data[2+2])<<8)|(this.data[2+3]))
    }
    return copy(this.buffer, this.data[6:]),nil
}

func (this *EIBConnection) EIB_Cache_LastUpdates2_async(start uint32, timeout uint8, buf []byte, ende *uint32) (int,error) {
    ibuf := make([]byte,7);
    _ = ibuf
    this.buffer = buf
    this.ptr7 = (*uint32)(ende)
    ibuf[2] = byte((start>>24)&0xff)
    ibuf[3] = byte((start>>16)&0xff)
    ibuf[4] = byte((start>>8)&0xff)
    ibuf[5] = byte((start)&0xff)
    ibuf[6] = byte((timeout)&0xff)
    ibuf[0] = 0
    ibuf[1] = 119
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_Cache_LastUpdates2_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_Cache_LastUpdates2(start uint32, timeout uint8, buf []byte, ende *uint32) (int,error) {
    _,err := this.EIB_Cache_LastUpdates2_async (start, timeout, buf, ende)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_LoadImage_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 99 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(uint16(((this.data[2])<<8)|(this.data[2+1]))),nil
}

func (this *EIBConnection) EIB_LoadImage_async(image []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    if len(image) < 0 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(image)
    ibuf = append(ibuf,image...)
    ibuf[0] = 0
    ibuf[1] = 99
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_LoadImage_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_LoadImage(image []byte) (int,error) {
    _,err := this.EIB_LoadImage_async (image)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Authorize_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 87 || len(this.data) < 3 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(this.data[2]),nil
}

func (this *EIBConnection) EIB_MC_Authorize_async(key []byte) (int,error) {
    ibuf := make([]byte,6);
    _ = ibuf
    if len(key) != 4 {
      return 0,fmt.Errorf("EINVAL")
    }
    copy(ibuf[2:6], key)
    ibuf[0] = 0
    ibuf[1] = 87
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Authorize_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Authorize(key []byte) (int,error) {
    _,err := this.EIB_MC_Authorize_async (key)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Connect_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 80 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Connect_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 80
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Connect_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Connect(dest EIBAddr) (int,error) {
    _,err := this.EIB_MC_Connect_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Individual_Open_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 73 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Individual_Open_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 73
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Individual_Open_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Individual_Open(dest EIBAddr) (int,error) {
    _,err := this.EIB_MC_Individual_Open_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_GetMaskVersion_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 89 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(uint16(((this.data[2])<<8)|(this.data[2+1]))),nil
}

func (this *EIBConnection) EIB_MC_GetMaskVersion_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 89
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_GetMaskVersion_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_GetMaskVersion() (int,error) {
    _,err := this.EIB_MC_GetMaskVersion_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_GetPEIType_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 85 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(uint16(((this.data[2])<<8)|(this.data[2+1]))),nil
}

func (this *EIBConnection) EIB_MC_GetPEIType_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 85
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_GetPEIType_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_GetPEIType() (int,error) {
    _,err := this.EIB_MC_GetPEIType_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Progmode_Off_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 96 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_Off_async() (int,error) {
    ibuf := make([]byte,3);
    _ = ibuf
    ibuf[2] = byte((0)&0xff)
    ibuf[0] = 0
    ibuf[1] = 96
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Progmode_Off_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_Off() (int,error) {
    _,err := this.EIB_MC_Progmode_Off_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Progmode_On_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 96 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_On_async() (int,error) {
    ibuf := make([]byte,3);
    _ = ibuf
    ibuf[2] = byte((1)&0xff)
    ibuf[0] = 0
    ibuf[1] = 96
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Progmode_On_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_On() (int,error) {
    _,err := this.EIB_MC_Progmode_On_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Progmode_Status_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 96 || len(this.data) < 3 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(this.data[2]),nil
}

func (this *EIBConnection) EIB_MC_Progmode_Status_async() (int,error) {
    ibuf := make([]byte,3);
    _ = ibuf
    ibuf[2] = byte((3)&0xff)
    ibuf[0] = 0
    ibuf[1] = 96
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Progmode_Status_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_Status() (int,error) {
    _,err := this.EIB_MC_Progmode_Status_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Progmode_Toggle_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 96 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_Toggle_async() (int,error) {
    ibuf := make([]byte,3);
    _ = ibuf
    ibuf[2] = byte((2)&0xff)
    ibuf[0] = 0
    ibuf[1] = 96
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Progmode_Toggle_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Progmode_Toggle() (int,error) {
    _,err := this.EIB_MC_Progmode_Toggle_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_PropertyDesc_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 97 || len(this.data) < 6 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr2 != nil {
      *(this.ptr2) = this.data[2]
    }
    if this.ptr4 != nil {
      *(this.ptr4) = uint16(((this.data[3])<<8)|(this.data[3+1]))
    }
    if this.ptr3 != nil {
      *(this.ptr3) = this.data[5]
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_PropertyDesc_async(obj uint8, propertyno uint8, proptype *uint8, max_nr_of_elem *uint16, access *uint8) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    this.ptr2 = (*uint8)(proptype)
    this.ptr4 = (*uint16)(max_nr_of_elem)
    this.ptr3 = (*uint8)(access)
    ibuf[2] = byte((obj)&0xff)
    ibuf[3] = byte((propertyno)&0xff)
    ibuf[0] = 0
    ibuf[1] = 97
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_PropertyDesc_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_PropertyDesc(obj uint8, propertyno uint8, proptype *uint8, max_nr_of_elem *uint16, access *uint8) (int,error) {
    _,err := this.EIB_MC_PropertyDesc_async (obj, propertyno, proptype, max_nr_of_elem, access)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_PropertyRead_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 83 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIB_MC_PropertyRead_async(obj uint8, propertyno uint8, start uint16, nr_of_elem uint8, buf []byte) (int,error) {
    ibuf := make([]byte,7);
    _ = ibuf
    this.buffer = buf
    ibuf[2] = byte((obj)&0xff)
    ibuf[3] = byte((propertyno)&0xff)
    ibuf[4] = byte((start>>8)&0xff)
    ibuf[5] = byte((start)&0xff)
    ibuf[6] = byte((nr_of_elem)&0xff)
    ibuf[0] = 0
    ibuf[1] = 83
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_PropertyRead_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_PropertyRead(obj uint8, propertyno uint8, start uint16, nr_of_elem uint8, buf []byte) (int,error) {
    _,err := this.EIB_MC_PropertyRead_async (obj, propertyno, start, nr_of_elem, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_PropertyScan_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 98 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIB_MC_PropertyScan_async(buf []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    ibuf[0] = 0
    ibuf[1] = 98
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_PropertyScan_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_PropertyScan(buf []byte) (int,error) {
    _,err := this.EIB_MC_PropertyScan_async (buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_PropertyWrite_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 84 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIB_MC_PropertyWrite_async(obj uint8, propertyno uint8, start uint16, nr_of_elem uint8, buf []byte, res []byte) (int,error) {
    ibuf := make([]byte,7);
    _ = ibuf
    ibuf[2] = byte((obj)&0xff)
    ibuf[3] = byte((propertyno)&0xff)
    ibuf[4] = byte((start>>8)&0xff)
    ibuf[5] = byte((start)&0xff)
    ibuf[6] = byte((nr_of_elem)&0xff)
    if len(buf) < 0 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(buf)
    ibuf = append(ibuf,buf...)
    this.buffer = res
    ibuf[0] = 0
    ibuf[1] = 84
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_PropertyWrite_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_PropertyWrite(obj uint8, propertyno uint8, start uint16, nr_of_elem uint8, buf []byte, res []byte) (int,error) {
    _,err := this.EIB_MC_PropertyWrite_async (obj, propertyno, start, nr_of_elem, buf, res)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_ReadADC_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 86 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr1 != nil {
      *(this.ptr1) = uint16(((this.data[2])<<8)|(this.data[2+1]))
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_ReadADC_async(channel uint8, count uint8, val *uint16) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    this.ptr1 = (*uint16)(val)
    ibuf[2] = byte((channel)&0xff)
    ibuf[3] = byte((count)&0xff)
    ibuf[0] = 0
    ibuf[1] = 86
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_ReadADC_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_ReadADC(channel uint8, count uint8, val *uint16) (int,error) {
    _,err := this.EIB_MC_ReadADC_async (channel, count, val)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Read_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 81 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIB_MC_Read_async(addr uint16, buf_len uint32, buf []byte) (int,error) {
    ibuf := make([]byte,6);
    _ = ibuf
    this.buffer = buf
    ibuf[2] = byte((addr>>8)&0xff)
    ibuf[3] = byte((addr)&0xff)
    ibuf[4] = byte((buf_len>>8)&0xff)
    ibuf[5] = byte((buf_len)&0xff)
    ibuf[0] = 0
    ibuf[1] = 81
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Read_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Read(addr uint16, buf_len uint32, buf []byte) (int,error) {
    _,err := this.EIB_MC_Read_async (addr, buf_len, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Restart_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 90 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Restart_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 90
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Restart_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Restart() (int,error) {
    _,err := this.EIB_MC_Restart_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_SetKey_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 2 {
      return 0,fmt.Errorf("EPERM")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 88 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_MC_SetKey_async(key []byte, level uint8) (int,error) {
    ibuf := make([]byte,7);
    _ = ibuf
    if len(key) != 4 {
      return 0,fmt.Errorf("EINVAL")
    }
    copy(ibuf[2:6], key)
    ibuf[6] = byte((level)&0xff)
    ibuf[0] = 0
    ibuf[1] = 88
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_SetKey_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_SetKey(key []byte, level uint8) (int,error) {
    _,err := this.EIB_MC_SetKey_async (key, level)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Write_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 68 {
      return 0,fmt.Errorf("EIO")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 82 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return this.sendlen,nil
}

func (this *EIBConnection) EIB_MC_Write_async(addr uint16, buf []byte) (int,error) {
    ibuf := make([]byte,6);
    _ = ibuf
    ibuf[2] = byte((addr>>8)&0xff)
    ibuf[3] = byte((addr)&0xff)
    ibuf[4] = byte(((len(buf))>>8)&0xff)
    ibuf[5] = byte(((len(buf)))&0xff)
    if len(buf) < 0 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(buf)
    ibuf = append(ibuf,buf...)
    ibuf[0] = 0
    ibuf[1] = 82
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Write_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Write(addr uint16, buf []byte) (int,error) {
    _,err := this.EIB_MC_Write_async (addr, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_MC_Write_Plain_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 91 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return this.sendlen,nil
}

func (this *EIBConnection) EIB_MC_Write_Plain_async(addr uint16, buf []byte) (int,error) {
    ibuf := make([]byte,6);
    _ = ibuf
    ibuf[2] = byte((addr>>8)&0xff)
    ibuf[3] = byte((addr)&0xff)
    ibuf[4] = byte(((len(buf))>>8)&0xff)
    ibuf[5] = byte(((len(buf)))&0xff)
    if len(buf) < 0 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(buf)
    ibuf = append(ibuf,buf...)
    ibuf[0] = 0
    ibuf[1] = 91
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_MC_Write_Plain_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_MC_Write_Plain(addr uint16, buf []byte) (int,error) {
    _,err := this.EIB_MC_Write_Plain_async (addr, buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_GetMaskVersion_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 49 || len(this.data) < 4 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(uint16(((this.data[2])<<8)|(this.data[2+1]))),nil
}

func (this *EIBConnection) EIB_M_GetMaskVersion_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 49
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_GetMaskVersion_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_GetMaskVersion(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_GetMaskVersion_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_Progmode_Off_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 48 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_Off_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[4] = byte((0)&0xff)
    ibuf[0] = 0
    ibuf[1] = 48
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_Progmode_Off_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_Off(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_Progmode_Off_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_Progmode_On_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 48 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_On_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[4] = byte((1)&0xff)
    ibuf[0] = 0
    ibuf[1] = 48
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_Progmode_On_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_On(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_Progmode_On_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_Progmode_Status_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 48 || len(this.data) < 3 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return int(this.data[2]),nil
}

func (this *EIBConnection) EIB_M_Progmode_Status_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[4] = byte((3)&0xff)
    ibuf[0] = 0
    ibuf[1] = 48
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_Progmode_Status_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_Status(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_Progmode_Status_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_Progmode_Toggle_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 48 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_Toggle_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[4] = byte((2)&0xff)
    ibuf[0] = 0
    ibuf[1] = 48
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_Progmode_Toggle_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_Progmode_Toggle(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_Progmode_Toggle_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_ReadIndividualAddresses_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 50 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return copy(this.buffer, this.data[2:]),nil
}

func (this *EIBConnection) EIB_M_ReadIndividualAddresses_async(buf []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.buffer = buf
    ibuf[0] = 0
    ibuf[1] = 50
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_ReadIndividualAddresses_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_ReadIndividualAddresses(buf []byte) (int,error) {
    _,err := this.EIB_M_ReadIndividualAddresses_async (buf)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIB_M_WriteIndividualAddress_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 65 {
      return 0,fmt.Errorf("EADDRINUSE")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 67 {
      return 0,fmt.Errorf("ETIMEDOUT")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 66 {
      return 0,fmt.Errorf("EADDRNOTAVAIL")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 64 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIB_M_WriteIndividualAddress_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 64
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIB_M_WriteIndividualAddress_Complete;
    return 0,nil
}

func (this *EIBConnection) EIB_M_WriteIndividualAddress(dest EIBAddr) (int,error) {
    _,err := this.EIB_M_WriteIndividualAddress_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenBusmonitor_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 16 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitor_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 16
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenBusmonitor_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitor() (int,error) {
    _,err := this.EIBOpenBusmonitor_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenBusmonitorText_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 17 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitorText_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 17
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenBusmonitorText_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitorText() (int,error) {
    _,err := this.EIBOpenBusmonitorText_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenBusmonitorTS_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 22 || len(this.data) < 6 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr7 != nil {
      *(this.ptr7) = uint32(((this.data[2])<<24)|((this.data[2+1])<<16)|((this.data[2+2])<<8)|(this.data[2+3]))
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitorTS_async(timebase *uint32) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.ptr7 = (*uint32)(timebase)
    ibuf[0] = 0
    ibuf[1] = 22
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenBusmonitorTS_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenBusmonitorTS(timebase *uint32) (int,error) {
    _,err := this.EIBOpenBusmonitorTS_async (timebase)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpen_GroupSocket_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 38 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpen_GroupSocket_async(write_only bool) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    if write_only != false {
      ibuf[4] = 0xff
    } else {
      ibuf[4] = 0x00
    }
    ibuf[0] = 0
    ibuf[1] = 38
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpen_GroupSocket_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpen_GroupSocket(write_only bool) (int,error) {
    _,err := this.EIBOpen_GroupSocket_async (write_only)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenT_Broadcast_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 35 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Broadcast_async(write_only bool) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    if write_only != false {
      ibuf[4] = 0xff
    } else {
      ibuf[4] = 0x00
    }
    ibuf[0] = 0
    ibuf[1] = 35
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenT_Broadcast_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Broadcast(write_only bool) (int,error) {
    _,err := this.EIBOpenT_Broadcast_async (write_only)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenT_Connection_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 32 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Connection_async(dest EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    ibuf[0] = 0
    ibuf[1] = 32
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenT_Connection_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Connection(dest EIBAddr) (int,error) {
    _,err := this.EIBOpenT_Connection_async (dest)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenT_Group_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 34 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Group_async(dest EIBAddr, write_only bool) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    if write_only != false {
      ibuf[4] = 0xff
    } else {
      ibuf[4] = 0x00
    }
    ibuf[0] = 0
    ibuf[1] = 34
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenT_Group_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Group(dest EIBAddr, write_only bool) (int,error) {
    _,err := this.EIBOpenT_Group_async (dest, write_only)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenT_Individual_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 33 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Individual_async(dest EIBAddr, write_only bool) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    if write_only != false {
      ibuf[4] = 0xff
    } else {
      ibuf[4] = 0x00
    }
    ibuf[0] = 0
    ibuf[1] = 33
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenT_Individual_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_Individual(dest EIBAddr, write_only bool) (int,error) {
    _,err := this.EIBOpenT_Individual_async (dest, write_only)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenT_TPDU_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 36 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_TPDU_async(src EIBAddr) (int,error) {
    ibuf := make([]byte,5);
    _ = ibuf
    ibuf[2] = byte((src>>8)&0xff)
    ibuf[3] = byte((src)&0xff)
    ibuf[0] = 0
    ibuf[1] = 36
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenT_TPDU_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenT_TPDU(src EIBAddr) (int,error) {
    _,err := this.EIBOpenT_TPDU_async (src)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenVBusmonitor_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 18 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitor_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 18
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenVBusmonitor_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitor() (int,error) {
    _,err := this.EIBOpenVBusmonitor_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenVBusmonitorText_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 19 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitorText_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 19
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenVBusmonitorText_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitorText() (int,error) {
    _,err := this.EIBOpenVBusmonitorText_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBOpenVBusmonitorTS_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) == 1 {
      return 0,fmt.Errorf("EBUSY")
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 23 || len(this.data) < 6 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    if this.ptr7 != nil {
      *(this.ptr7) = uint32(((this.data[2])<<24)|((this.data[2+1])<<16)|((this.data[2+2])<<8)|(this.data[2+3]))
    }
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitorTS_async(timebase *uint32) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    this.ptr7 = (*uint32)(timebase)
    ibuf[0] = 0
    ibuf[1] = 23
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBOpenVBusmonitorTS_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBOpenVBusmonitorTS(timebase *uint32) (int,error) {
    _,err := this.EIBOpenVBusmonitorTS_async (timebase)
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) __EIBReset_Complete() (int,error) {
    this.__complete = nil
    err := this.__EIB_GetRequest()
    if err != nil {
      return 0,err;
    }
    if uint16(((this.data[0])<<8)|(this.data[0+1])) != 4 || len(this.data) < 2 {
      return 0,fmt.Errorf("ECONNRESET")
    }
    return 0,nil
}

func (this *EIBConnection) EIBReset_async() (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    ibuf[0] = 0
    ibuf[1] = 4
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    this.__complete = this.__EIBReset_Complete;
    return 0,nil
}

func (this *EIBConnection) EIBReset() (int,error) {
    _,err := this.EIBReset_async ()
    if err != nil {
      return 0,err
    }
    return this.EIBComplete ()}

func (this *EIBConnection) EIBSendAPDU(data []byte) (int,error) {
    ibuf := make([]byte,2);
    _ = ibuf
    if len(data) < 2 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(data)
    ibuf = append(ibuf,data...)
    ibuf[0] = 0
    ibuf[1] = 37
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    return this.sendlen,nil
}

func (this *EIBConnection) EIBSendGroup(dest EIBAddr, data []byte) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    if len(data) < 2 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(data)
    ibuf = append(ibuf,data...)
    ibuf[0] = 0
    ibuf[1] = 39
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    return this.sendlen,nil
}

func (this *EIBConnection) EIBSendTPDU(dest EIBAddr, data []byte) (int,error) {
    ibuf := make([]byte,4);
    _ = ibuf
    ibuf[2] = byte((dest>>8)&0xff)
    ibuf[3] = byte((dest)&0xff)
    if len(data) < 2 {
      return 0,fmt.Errorf("EINVAL")
    }
    this.sendlen = len(data)
    ibuf = append(ibuf,data...)
    ibuf[0] = 0
    ibuf[1] = 37
    err := this.__EIB_SendRequest(ibuf)
    if err != nil {
      return 0,err;
    }
    return this.sendlen,nil
}

