
from __future__ import absolute_import, print_function, unicode_literals
del absolute_import, print_function, unicode_literals

from . import encoding
__all__ = ['encoding']
